function initMap() {
    // The location of Uluru
    var uluru = {lat: 11.0168, lng: 76.9558};
   // var uluru1 = {lat: 14.0168, lng: 76.9558};
    // The map, centered at Uluru
    var map = new google.maps.Map(
        document.getElementById('map'), {zoom: 12, center: uluru});
        // var map1 = new google.maps.Map(
        //     document.getElementById('map'), {zoom: 12, center: uluru1});
    // The marker, positioned at Uluru
    var marker = new google.maps.Marker({position: uluru, map: map});
    //var marker1 = new google.maps.Marker({position: uluru, map: map});
    marker.setAnimation(google.maps.Animation.BOUNCE);
  }