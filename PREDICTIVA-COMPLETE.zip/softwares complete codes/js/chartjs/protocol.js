var firebaseConfig = {
    apiKey: "AIzaSyCRWeRMdFDag137591pXZhkJojrgEnRhng",
    authDomain: "temperature-i2c.firebaseapp.com",
    databaseURL: "https://temperature-i2c.firebaseio.com",
    projectId: "temperature-i2c",
    storageBucket: "temperature-i2c.appspot.com",
    messagingSenderId: "663070648032",
    appId: "1:663070648032:web:cae3126b8a1ff3ddf09285",
    measurementId: "G-NBX8M39DEG"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  var database = firebase.database();
  firebase.auth.Auth.Persistence.LOCAL;



  var database0=firebase.database();
  var protocol_select = database0.ref("PROTOCOL/");
  protocol_select.once('value',function(snapshot){
      snapshot.forEach(function(childSnapshot){
      var protocol_data=childSnapshot.val();
      data1=JSON.stringify(protocol_data);
      data2=JSON.parse(data1);
      console.log(protocol_data.protocol);
      console.log(data2.protocol);
     });
  });

