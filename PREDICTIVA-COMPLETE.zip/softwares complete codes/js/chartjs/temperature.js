
var firebaseConfig = {
    apiKey: "AIzaSyCRWeRMdFDag137591pXZhkJojrgEnRhng",
    authDomain: "temperature-i2c.firebaseapp.com",
    databaseURL: "https://temperature-i2c.firebaseio.com",
    projectId: "temperature-i2c",
    storageBucket: "temperature-i2c.appspot.com",
    messagingSenderId: "663070648032",
    appId: "1:663070648032:web:cae3126b8a1ff3ddf09285",
    measurementId: "G-NBX8M39DEG"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  var database = firebase.database();
  firebase.auth.Auth.Persistence.LOCAL;

FusionCharts.ready(function() {
    var stockPriceChart = new FusionCharts({
        id: "stockRealTimeChart",
        type: 'realtimeline',
        renderAt: 'chart-container',
        width: '430',
        height: '250',
        //theme:'candy',
        dataFormat: 'json',
        //animationEnables:true,
        dataSource: {
          "chart": {
            "caption": "Temperature",
            "showBorder": "0",
            //"borderThickness": "3",
            "showcanvasBorderRadius":"40",
            //"subCaption": "Harry's SuperMart",
            "xAxisName": "Time",
            "yAxisName": "Temperature",
            "lineColor":"f9812a",
            //"numberPrefix": "$",
            "refreshinterval": "5",
            //"yaxisminvalue": "40",
            //"yaxismaxvalue": "200",
            "numdisplaysets": "10",
            "outCnvBaseFont": "Arial",
            "outCnvBaseFontSize": "11",
            "outCnvBaseFontColor": "#000000",
            "type":"circle",
            "labeldisplay": "rotate",
            "showRealTimeValue": "0",
            "bgColor": "#FFFFFF",
             // "bgratio": "60,40",
             // "bgAlpha": "70,80",
            "bgAngle": "180",
            "anchorRadius": "5",
            "anchorBorderThickness": "2",
            "anchorBorderColor": "#127fcb",
            "anchorSides": "3",
            "anchorBgColor": "#d3f7ff",
            "theme": "fusion"
          },
          "categories": [{
            "category": [{
              "label": "Day Start"
            }]
          }],
          "dataset": [{
            "data": [{
              "value": "70"
            }]
          }]
        },
        "events": {
          "initialized": function(e) {
            function addLeadingZero(num) {
              return (num <= 9) ? ("0" + num) : num;
            }
                function updateData() {
              // Get reference to the chart using its ID
              var chartRef = FusionCharts("stockRealTimeChart"),
                // We need to create a querystring format incremental update, containing
                // label in hh:mm:ss format
                // and a value (random).
                currDate = new Date(),
                label = addLeadingZero(currDate.getHours()) + ":" +
                addLeadingZero(currDate.getMinutes()) + ":" +
                addLeadingZero(currDate.getSeconds()),
                // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
               //randomValue = Math.floor(Math.random() *
                 // 50) / 100 + 35.25
                     database=firebase.database();
                     firedata=new Array();
                     //temp=new Array();
                     i=0;  
                        var leadsRef =database.ref("UART/");
                        leadsRef.limitToLast(1).on('value', function(snapshot) {
                        snapshot.forEach(function(childSnapshot) {
                        var childData = childSnapshot.val();
                        firedata.push(childData);
                        data=firedata[firedata.length- 1];
                        //console.log(data);
                        data1=JSON.stringify(data);
                        //console.log(data1);
                        data2=JSON.parse(data1);
                       // console.log(data2.Temperature);
                      /* for(i=0;i<firedata.length;i++){
                             console.log(firedata[i]); 
                             temp1=JSON.parse(firedata[i]);
                             console.log(temp1.temp)
                             strData = "&label=" + label +
                            "&value=" +(temp1.temp); 
                       }*/
                        });
                 });
                 strData = "&label=" + label +
                          "&value=" +data2.Temperature; 
             // console.log(strData);
              chartRef.feedData(strData);
            }
            var myVar = setInterval(function() {
              updateData();
            }, 5000);
          }
        }
      })
      .render();
  }); 
                          