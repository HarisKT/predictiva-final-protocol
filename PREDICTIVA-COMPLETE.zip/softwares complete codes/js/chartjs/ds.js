var firebaseConfig = {
  apiKey: "AIzaSyCRWeRMdFDag137591pXZhkJojrgEnRhng",
  authDomain: "temperature-i2c.firebaseapp.com",
  databaseURL: "https://temperature-i2c.firebaseio.com",
  projectId: "temperature-i2c",
  storageBucket: "temperature-i2c.appspot.com",
  messagingSenderId: "663070648032",
  appId: "1:663070648032:web:cae3126b8a1ff3ddf09285",
  measurementId: "G-NBX8M39DEG"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
var database = firebase.database();
firebase.auth.Auth.Persistence.LOCAL;



var database0=firebase.database();
var protocol_select = database0.ref("PROTOCOL");
protocol_select.on('value',function(snapshot){
    var protocol_data=snapshot.val();
    protocol_data_stringify=JSON.stringify(protocol_data);
    protocol_data_parse=JSON.parse( protocol_data_stringify);
    //console.log(protocol_data.protocol);
    console.log(protocol_data_parse.protocol);  
    if(protocol_data_parse.protocol=="UART") {
      FusionCharts.ready(function() {
        var stockPriceChart = new FusionCharts({
            id: "stockRealTimeChart",
            type: 'realtimeline',
            renderAt: 'chart-container',
            width: '430',
            height: '250',
            //theme:'candy',
            dataFormat: 'json',
            //animationEnables:true,
            dataSource: {
              "chart": {
                "caption": "Temperature",
                "showBorder": "0",
                //"borderThickness": "3",
                "showcanvasBorderRadius":"40",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Temperature",
                "lineColor":"f9812a",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "outCnvBaseFont": "Arial",
                "outCnvBaseFontSize": "11",
                "outCnvBaseFontColor": "#000000",
                "type":"circle",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "bgColor": "#FFFFFF",
                 // "bgratio": "60,40",
                 // "bgAlpha": "70,80",
                "bgAngle": "180",
                "anchorRadius": "5",
                "anchorBorderThickness": "2",
                "anchorBorderColor": "#127fcb",
                "anchorSides": "3",
                "anchorBgColor": "#d3f7ff",
                "theme": "fusion"
              },
              "categories": [{
                "category": [{
                  "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData() {
                  // Get reference to the chart using its ID
                  var chartRef = FusionCharts("stockRealTimeChart"),
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database=firebase.database();
                         firedata=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef =database.ref("UART/");
                            leadsRef.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData = childSnapshot.val();
                            firedata.push(childData);
                            data=firedata[firedata.length- 1];
                            data1=JSON.stringify(data);
                            data2=JSON.parse(data1);
                            //console.log(data2.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData = "&label=" + label +
                              "&value=" +data2.Temperature; 
                  //console.log(strData);
                  chartRef.feedData(strData);
                }
                var myVar = setInterval(function() {
                  updateData();
                }, 5000);
              }
            }
          })
          .render();
      });   
      FusionCharts.ready(function() {
        var stockPriceChart1 = new FusionCharts({
            id: "mychart",
            type: 'realtimeline',
            renderAt: 'chart-container1',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "canvasBorderRadius":"10",
                "showBorder": "0",
                "lineColor":"f9812a",
               // "showBorder": "1",
                //"borderThickness": "3",
                "showcanvasBorderRadius":"40",
                "caption": "Vibration",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Vibration",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                 // "bgratio": "60,40",
                 // "bgAlpha": "70,80",
                "bgAngle": "180",
      
                "outCnvBaseFont": "Arial",
                "outCnvBaseFontSize": "11",
                "outCnvBaseFontColor": "#000000",
      
                "anchorRadius": "5",
                "anchorBorderThickness": "2",
                "anchorBorderColor": "#127fcb",
                "anchorSides": "3",
                "anchorBgColor": "#d3f7ff"
      
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData1() {
                  // Get reference to the chart using its ID
                  var chartRef1 = FusionCharts("mychart"),
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate1 = new Date(),
                    label = addLeadingZero(currDate1.getHours()) + ":" +
                    addLeadingZero(currDate1.getMinutes()) + ":" +
                    addLeadingZero(currDate1.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database1=firebase.database();
                         firedata1=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef1 =database1.ref("UART/");
                            leadsRef1.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData1 = childSnapshot.val();
                            firedata1.push(childData1);
                            data01=firedata1[firedata1.length- 1];
                            data02=JSON.stringify(data01);
                            data03=JSON.parse(data02);
                            //console.log(data03.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData1 = "&label=" + label +
                              "&value=" +data03.Vibration; 
                  //console.log(strData1);
                  chartRef1.feedData(strData1);
                }
                var myVar1 = setInterval(function() {
                  updateData1();
                }, 5000);
              }
            }
          })
          .render();
      });       
      
      FusionCharts.ready(function() {
        var stockPriceChart2 = new FusionCharts({
            id: "stackRealTimeChart2",
            type: 'realtimeline',
            renderAt: 'chart-container2',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "lineColor":"f9812a",
                  "showBorder": "0",
                  //"borderThickness": "3",
                  //"showcanvasBorderRadius":"40",
                "caption": "Current",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Current",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                   // "bgratio": "60,40",
                   // "bgAlpha": "70,80",
                  "bgAngle": "180",
                  "outCnvBaseFont": "Arial",
                  "outCnvBaseFontSize": "11",
                  "outCnvBaseFontColor": "#000000",
      
                  "anchorRadius": "5",
                  "anchorBorderThickness": "2",
                  "anchorBorderColor": "#127fcb",
                  "anchorSides": "3",
                  "anchorBgColor": "#d3f7ff"
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData2() {
                  // Get reference to the chart using its ID
                  var chartRef2 = e.sender,
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database2=firebase.database();
                         firedata2=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef2 =database2.ref("UART/");
                            leadsRef2.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData2 = childSnapshot.val();
                            firedata2.push(childData2);
                            data001=firedata2[firedata2.length- 1];
                            data002=JSON.stringify(data001);
                            data003=JSON.parse(data002);
                           // console.log(data003.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData2 = "&label=" + label +
                              "&value=" +data003.current; 
                 // console.log(strData2);
                  chartRef2.feedData(strData2);
                }
                var myVar2 = setInterval(function() {
                  updateData2();
                }, 5000);
              }
            }
          })
          .render();
      });     
      
      FusionCharts.ready(function() {
        var stockPriceChart2 = new FusionCharts({
            id: "stockRealTimeChart3",
            type: 'realtimeline',
            renderAt: 'chart-container3',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "lineColor":"f9812a",
                  "showBorder": "0",
                  //"borderThickness": "3",
                
                "caption": "Voltage",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Voltage",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                   // "bgratio": "60,40",
                   // "bgAlpha": "70,80",
                  "bgAngle": "180",
      
                  "outCnvBaseFont": "Arial",
                  "outCnvBaseFontSize": "11",
                  "outCnvBaseFontColor": "#000000",
      
                  "anchorRadius": "5",
                  "anchorBorderThickness": "2",
                  "anchorBorderColor": "#127fcb",
                  "anchorSides": "3",
                  "anchorBgColor": "#d3f7ff"
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData3() {
                  // Get reference to the chart using its ID
                //  var chartRef3 = FusionCharts("stockRealTimeChart"),
                    var chartRef3=e.sender,
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database3=firebase.database();
                         firedata3=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef3 =database3.ref("UART/");
                            leadsRef3.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData3 = childSnapshot.val();
                            firedata3.push(childData3);
                            data0001=firedata3[firedata3.length- 1];
                            data0002=JSON.stringify(data0001);
                            data0003=JSON.parse(data0002);
                            //console.log(data0003.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData3 = "&label=" + label +
                              "&value=" +data0003.volt; 
                 // console.log(strData3);
                  chartRef3.feedData(strData3);
                }
                var myVar3 = setInterval(function() {
                  updateData3();
                }, 5000);
              }
            }
          })
          .render();
      });  
    }




    else if(protocol_data_parse.protocol=="I2C"){

      FusionCharts.ready(function() {
        var stockPriceChart = new FusionCharts({
            id: "stockRealTimeChart",
            type: 'realtimeline',
            renderAt: 'chart-container',
            width: '430',
            height: '250',
            //theme:'candy',
            dataFormat: 'json',
            //animationEnables:true,
            dataSource: {
              "chart": {
                "caption": "Temperature",
                "showBorder": "0",
                //"borderThickness": "3",
                "showcanvasBorderRadius":"40",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Temperature",
                "lineColor":"f9812a",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "outCnvBaseFont": "Arial",
                "outCnvBaseFontSize": "11",
                "outCnvBaseFontColor": "#000000",
                "type":"circle",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "bgColor": "#FFFFFF",
                 // "bgratio": "60,40",
                 // "bgAlpha": "70,80",
                "bgAngle": "180",
                "anchorRadius": "5",
                "anchorBorderThickness": "2",
                "anchorBorderColor": "#127fcb",
                "anchorSides": "3",
                "anchorBgColor": "#d3f7ff",
                "theme": "fusion"
              },
              "categories": [{
                "category": [{
                  "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData() {
                  // Get reference to the chart using its ID
                  var chartRef = FusionCharts("stockRealTimeChart"),
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database=firebase.database();
                         firedata=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef =database.ref("I2C/");
                            leadsRef.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData = childSnapshot.val();
                            firedata.push(childData);
                            data=firedata[firedata.length- 1];
                            data1=JSON.stringify(data);
                            data2=JSON.parse(data1);
                            //console.log(data2.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData = "&label=" + label +
                              "&value=" +data2.temp; 
                  //console.log(strData);
                  chartRef.feedData(strData);
                }
                var myVar = setInterval(function() {
                  updateData();
                }, 5000);
              }
            }
          })
          .render();
      });   
      FusionCharts.ready(function() {
        var stockPriceChart1 = new FusionCharts({
            id: "mychart",
            type: 'realtimeline',
            renderAt: 'chart-container1',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "canvasBorderRadius":"10",
                "showBorder": "0",
                "lineColor":"f9812a",
               // "showBorder": "1",
                //"borderThickness": "3",
                "showcanvasBorderRadius":"40",
                "caption": "Vibration",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Vibration",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                 // "bgratio": "60,40",
                 // "bgAlpha": "70,80",
                "bgAngle": "180",
      
                "outCnvBaseFont": "Arial",
                "outCnvBaseFontSize": "11",
                "outCnvBaseFontColor": "#000000",
      
                "anchorRadius": "5",
                "anchorBorderThickness": "2",
                "anchorBorderColor": "#127fcb",
                "anchorSides": "3",
                "anchorBgColor": "#d3f7ff"
      
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData1() {
                  // Get reference to the chart using its ID
                  var chartRef1 = FusionCharts("mychart"),
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate1 = new Date(),
                    label = addLeadingZero(currDate1.getHours()) + ":" +
                    addLeadingZero(currDate1.getMinutes()) + ":" +
                    addLeadingZero(currDate1.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database1=firebase.database();
                         firedata1=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef1 =database1.ref("I2C/");
                            leadsRef1.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData1 = childSnapshot.val();
                            firedata1.push(childData1);
                            data01=firedata1[firedata1.length- 1];
                            data02=JSON.stringify(data01);
                            data03=JSON.parse(data02);
                            //console.log(data03.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData1 = "&label=" + label +
                              "&value=" +data03.temp; 
                  //console.log(strData1);
                  chartRef1.feedData(strData1);
                }
                var myVar1 = setInterval(function() {
                  updateData1();
                }, 5000);
              }
            }
          })
          .render();
      });       
      
      FusionCharts.ready(function() {
        var stockPriceChart2 = new FusionCharts({
            id: "stackRealTimeChart2",
            type: 'realtimeline',
            renderAt: 'chart-container2',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "lineColor":"f9812a",
                  "showBorder": "0",
                  //"borderThickness": "3",
                  //"showcanvasBorderRadius":"40",
                "caption": "Current",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Current",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                   // "bgratio": "60,40",
                   // "bgAlpha": "70,80",
                  "bgAngle": "180",
                  "outCnvBaseFont": "Arial",
                  "outCnvBaseFontSize": "11",
                  "outCnvBaseFontColor": "#000000",
      
                  "anchorRadius": "5",
                  "anchorBorderThickness": "2",
                  "anchorBorderColor": "#127fcb",
                  "anchorSides": "3",
                  "anchorBgColor": "#d3f7ff"
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData2() {
                  // Get reference to the chart using its ID
                  var chartRef2 = e.sender,
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database2=firebase.database();
                         firedata2=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef2 =database2.ref("I2C/");
                            leadsRef2.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData2 = childSnapshot.val();
                            firedata2.push(childData2);
                            data001=firedata2[firedata2.length- 1];
                            data002=JSON.stringify(data001);
                            data003=JSON.parse(data002);
                           // console.log(data003.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData2 = "&label=" + label +
                              "&value=" +data003.temp; 
                 // console.log(strData2);
                  chartRef2.feedData(strData2);
                }
                var myVar2 = setInterval(function() {
                  updateData2();
                }, 5000);
              }
            }
          })
          .render();
      });     
      
      FusionCharts.ready(function() {
        var stockPriceChart2 = new FusionCharts({
            id: "stockRealTimeChart3",
            type: 'realtimeline',
            renderAt: 'chart-container3',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "lineColor":"f9812a",
                  "showBorder": "0",
                  //"borderThickness": "3",
                
                "caption": "Voltage",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Voltage",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                   // "bgratio": "60,40",
                   // "bgAlpha": "70,80",
                  "bgAngle": "180",
      
                  "outCnvBaseFont": "Arial",
                  "outCnvBaseFontSize": "11",
                  "outCnvBaseFontColor": "#000000",
      
                  "anchorRadius": "5",
                  "anchorBorderThickness": "2",
                  "anchorBorderColor": "#127fcb",
                  "anchorSides": "3",
                  "anchorBgColor": "#d3f7ff"
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData3() {
                  // Get reference to the chart using its ID
                //  var chartRef3 = FusionCharts("stockRealTimeChart"),
                    var chartRef3=e.sender,
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database3=firebase.database();
                         firedata3=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef3 =database3.ref("I2C/");
                            leadsRef3.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData3 = childSnapshot.val();
                            firedata3.push(childData3);
                            data0001=firedata3[firedata3.length- 1];
                            data0002=JSON.stringify(data0001);
                            data0003=JSON.parse(data0002);
                            //console.log(data0003.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData3 = "&label=" + label +
                              "&value=" +data0003.temp; 
                 // console.log(strData3);
                  chartRef3.feedData(strData3);
                }
                var myVar3 = setInterval(function() {
                  updateData3();
                }, 5000);
              }
            }
          })
          .render();
      });
    }







    else if(protocol_data_parse.protocol=="SPI"){
      FusionCharts.ready(function() {
        var stockPriceChart = new FusionCharts({
            id: "stockRealTimeChart",
            type: 'realtimeline',
            renderAt: 'chart-container',
            width: '430',
            height: '250',
            //theme:'candy',
            dataFormat: 'json',
            //animationEnables:true,
            dataSource: {
              "chart": {
                "caption": "Temperature",
                "showBorder": "0",
                //"borderThickness": "3",
                "showcanvasBorderRadius":"40",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Temperature",
                "lineColor":"f9812a",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "outCnvBaseFont": "Arial",
                "outCnvBaseFontSize": "11",
                "outCnvBaseFontColor": "#000000",
                "type":"circle",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "bgColor": "#FFFFFF",
                 // "bgratio": "60,40",
                 // "bgAlpha": "70,80",
                "bgAngle": "180",
                "anchorRadius": "5",
                "anchorBorderThickness": "2",
                "anchorBorderColor": "#127fcb",
                "anchorSides": "3",
                "anchorBgColor": "#d3f7ff",
                "theme": "fusion"
              },
              "categories": [{
                "category": [{
                  "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData() {
                  // Get reference to the chart using its ID
                  var chartRef = FusionCharts("stockRealTimeChart"),
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database=firebase.database();
                         firedata=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef =database.ref("SPI/Voltage");
                            leadsRef.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData = childSnapshot.val();
                            firedata.push(childData);
                            data=firedata[firedata.length- 1];
                            data1=JSON.stringify(data);
                            data2=JSON.parse(data1);
                            //console.log(data2.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData = "&label=" + label +
                              "&value=" +data2.Temperature; 
                  //console.log(strData);
                  chartRef.feedData(strData);
                }
                var myVar = setInterval(function() {
                  updateData();
                }, 5000);
              }
            }
          })
          .render();
      });   
      FusionCharts.ready(function() {
        var stockPriceChart1 = new FusionCharts({
            id: "mychart",
            type: 'realtimeline',
            renderAt: 'chart-container1',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "canvasBorderRadius":"10",
                "showBorder": "0",
                "lineColor":"f9812a",
               // "showBorder": "1",
                //"borderThickness": "3",
                "showcanvasBorderRadius":"40",
                "caption": "Vibration",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Vibration",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                 // "bgratio": "60,40",
                 // "bgAlpha": "70,80",
                "bgAngle": "180",
      
                "outCnvBaseFont": "Arial",
                "outCnvBaseFontSize": "11",
                "outCnvBaseFontColor": "#000000",
      
                "anchorRadius": "5",
                "anchorBorderThickness": "2",
                "anchorBorderColor": "#127fcb",
                "anchorSides": "3",
                "anchorBgColor": "#d3f7ff"
      
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData1() {
                  // Get reference to the chart using its ID
                  var chartRef1 = FusionCharts("mychart"),
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate1 = new Date(),
                    label = addLeadingZero(currDate1.getHours()) + ":" +
                    addLeadingZero(currDate1.getMinutes()) + ":" +
                    addLeadingZero(currDate1.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database1=firebase.database();
                         firedata1=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef1 =database1.ref("SPI/Voltage");
                            leadsRef1.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData1 = childSnapshot.val();
                            firedata1.push(childData1);
                            data01=firedata1[firedata1.length- 1];
                            data02=JSON.stringify(data01);
                            data03=JSON.parse(data02);
                            //console.log(data03.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData1 = "&label=" + label +
                              "&value=" +data03.vibration; 
                  //console.log(strData1);
                  chartRef1.feedData(strData1);
                }
                var myVar1 = setInterval(function() {
                  updateData1();
                }, 5000);
              }
            }
          })
          .render();
      });       
      
      FusionCharts.ready(function() {
        var stockPriceChart2 = new FusionCharts({
            id: "stackRealTimeChart2",
            type: 'realtimeline',
            renderAt: 'chart-container2',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "lineColor":"f9812a",
                  "showBorder": "0",
                  //"borderThickness": "3",
                  //"showcanvasBorderRadius":"40",
                "caption": "Current",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Current",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                   // "bgratio": "60,40",
                   // "bgAlpha": "70,80",
                  "bgAngle": "180",
                  "outCnvBaseFont": "Arial",
                  "outCnvBaseFontSize": "11",
                  "outCnvBaseFontColor": "#000000",
      
                  "anchorRadius": "5",
                  "anchorBorderThickness": "2",
                  "anchorBorderColor": "#127fcb",
                  "anchorSides": "3",
                  "anchorBgColor": "#d3f7ff"
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData2() {
                  // Get reference to the chart using its ID
                  var chartRef2 = e.sender,
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database2=firebase.database();
                         firedata2=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef2 =database2.ref("SPI/Voltage");
                            leadsRef2.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData2 = childSnapshot.val();
                            firedata2.push(childData2);
                            data001=firedata2[firedata2.length- 1];
                            data002=JSON.stringify(data001);
                            data003=JSON.parse(data002);
                           // console.log(data003.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData2 = "&label=" + label +
                              "&value=" +data003.current; 
                 // console.log(strData2);
                  chartRef2.feedData(strData2);
                }
                var myVar2 = setInterval(function() {
                  updateData2();
                }, 5000);
              }
            }
          })
          .render();
      });     
      
      FusionCharts.ready(function() {
        var stockPriceChart2 = new FusionCharts({
            id: "stockRealTimeChart3",
            type: 'realtimeline',
            renderAt: 'chart-container3',
            width: '430',
            height: '250',
            dataFormat: 'json',
            dataSource: {
              "chart": {
                "lineColor":"f9812a",
                  "showBorder": "0",
                  //"borderThickness": "3",
                
                "caption": "Voltage",
                //"subCaption": "Harry's SuperMart",
                "xAxisName": "Time",
                "yAxisName": "Voltage",
                //"numberPrefix": "$",
                "refreshinterval": "5",
                //"yaxisminvalue": "40",
                //"yaxismaxvalue": "200",
                "numdisplaysets": "10",
                "labeldisplay": "rotate",
                "showRealTimeValue": "0",
                "theme": "fusion",
                "bgColor": "#FFFFFF",
                   // "bgratio": "60,40",
                   // "bgAlpha": "70,80",
                  "bgAngle": "180",
      
                  "outCnvBaseFont": "Arial",
                  "outCnvBaseFontSize": "11",
                  "outCnvBaseFontColor": "#000000",
      
                  "anchorRadius": "5",
                  "anchorBorderThickness": "2",
                  "anchorBorderColor": "#127fcb",
                  "anchorSides": "3",
                  "anchorBgColor": "#d3f7ff"
              },
              "categories": [{
                "category": [{
                 "label": "Day Start"
                }]
              }],
              "dataset": [{
                "data": [{
                  "value": "70"
                }]
              }]
            },
            "events": {
              "initialized": function(e) {
                function addLeadingZero(num) {
                  return (num <= 9) ? ("0" + num) : num;
                }
                    function updateData3() {
                  // Get reference to the chart using its ID
                //  var chartRef3 = FusionCharts("stockRealTimeChart"),
                    var chartRef3=e.sender,
                    // We need to create a querystring format incremental update, containing
                    // label in hh:mm:ss format
                    // and a value (random).
                    currDate = new Date(),
                    label = addLeadingZero(currDate.getHours()) + ":" +
                    addLeadingZero(currDate.getMinutes()) + ":" +
                    addLeadingZero(currDate.getSeconds()),
                    // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
                   //randomValue = Math.floor(Math.random() *
                     // 50) / 100 + 35.25
                         database3=firebase.database();
                         firedata3=new Array();
                         //temp=new Array();
                         i=0;  
                            var leadsRef3 =database3.ref("SPI/Voltage");
                            leadsRef3.limitToLast(1).on('value', function(snapshot) {
                            snapshot.forEach(function(childSnapshot) {
                            var childData3 = childSnapshot.val();
                            firedata3.push(childData3);
                            data0001=firedata3[firedata3.length- 1];
                            data0002=JSON.stringify(data0001);
                            data0003=JSON.parse(data0002);
                            //console.log(data0003.temp);
                          /* for(i=0;i<firedata.length;i++){
                                 console.log(firedata[i]); 
                                 temp1=JSON.parse(firedata[i]);
                                 console.log(temp1.temp)
                                 strData = "&label=" + label +
                                "&value=" +(temp1.temp); 
                           }*/
                            });
                     });
                     strData3 = "&label=" + label +
                              "&value=" +data0003.volt; 
                 // console.log(strData3);
                  chartRef3.feedData(strData3);
                }
                var myVar3 = setInterval(function() {
                  updateData3();
                }, 5000);
              }
            }
          })
          .render();
      });
    }




  });




/*FusionCharts.ready(function() {
  var stockPriceChart4 = new FusionCharts({
      id: "stackRealTimeChart4",
      type: 'realtimeline',
      renderAt: 'chart-container4',
      width: '430',
      height: '250',
      dataFormat: 'json',
      dataSource: {
        "chart": {
          "showBorder": "0",
               //"borderThickness": "3",
          "lineColor":"f9812a",  
          "caption": "Load",
          //"subCaption": "Harry's SuperMart",
          "xAxisName": "Time",
          "yAxisName": "Load",
          //"numberPrefix": "$",
          "refreshinterval": "5",
          //"yaxisminvalue": "40",
          //"yaxismaxvalue": "200",
          "numdisplaysets": "10",
          "labeldisplay": "rotate",
          "showRealTimeValue": "0",
          "theme": "fusion",
          "bgColor": "#FFFFFF",
                // "bgratio": "60,40",
                // "bgAlpha": "70,80",
            "bgAngle": "180",
              
            "outCnvBaseFont": "Arial",
             "outCnvBaseFontSize": "11",
             "outCnvBaseFontColor": "#000000",
              
             "anchorRadius": "5",
             "anchorBorderThickness": "2",
             "anchorBorderColor": "#127fcb",
             "anchorSides": "3",
             "anchorBgColor": "#d3f7ff"
        },
        "categories": [{
          "category": [{
           "label": "Day Start"
          }]
        }],
        "dataset": [{
          "data": [{
            "value": "70"
          }]
        }]
      },
      "events": {
        "initialized": function(e) {
          function addLeadingZero(num) {
            return (num <= 9) ? ("0" + num) : num;
          }
              function updateData4() {
            // Get reference to the chart using its ID
            var chartRef4 = e.sender,
              // We need to create a querystring format incremental update, containing
              // label in hh:mm:ss format
              // and a value (random).
              currDate = new Date(),
              label = addLeadingZero(currDate.getHours()) + ":" +
              addLeadingZero(currDate.getMinutes()) + ":" +
              addLeadingZero(currDate.getSeconds()),
              // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
             //randomValue = Math.floor(Math.random() *
               // 50) / 100 + 35.25
                   database4=firebase.database();
                   firedata4=new Array();
                   //temp=new Array();
                   i=0;  
                      var leadsRef4 =database4.ref("UART/");
                      leadsRef4.limitToLast(1).on('value', function(snapshot) {
                      snapshot.forEach(function(childSnapshot) {
                      var childData4 = childSnapshot.val();
                      firedata4.push(childData4);
                      data00001=firedata4[firedata4.length- 1];
                      data00002=JSON.stringify(data00001);
                      data00003=JSON.parse(data00002);
                      console.log(data00003.temp);
                    /* for(i=0;i<firedata.length;i++){
                           console.log(firedata[i]); 
                           temp1=JSON.parse(firedata[i]);
                           console.log(temp1.temp)
                           strData = "&label=" + label +
                          "&value=" +(temp1.temp); 
                     }
                      });
               });
               strData4 = "&label=" + label +
                        "&value=" +data00003.temp; 
            console.log(strData4);
            chartRef4.feedData(strData4);
          }
          var myVar4 = setInterval(function() {
            updateData4();
          }, 5000);
        }
      }
    })
    .render();
});

FusionCharts.ready(function() {
  var stockPriceChart5 = new FusionCharts({
      id: "stockRealTimeChart5",
      type: 'realtimeline',
      renderAt: 'chart-container5',
      width: '430',
      height: '250',
      dataFormat: 'json',
      dataSource: {
        "chart": {
          "showBorder": "0",
          "caption": "RPM",
          "captionBorder":"10",
          "lineColor":"f9812a",
          //"subCaption": "Harry's SuperMart",
          "xAxisName": "Time",
          "yAxisName": "RPM",
          //"numberPrefix": "$",
          "refreshinterval": "5",
          //"yaxisminvalue": "40",
          //"yaxismaxvalue": "200",
          "numdisplaysets": "10",
          "labeldisplay": "rotate",
          "showRealTimeValue": "0",
          "theme": "fusion",
          
          "bgColor": "#FFFFFF",
                      // "bgratio": "60,40",
                      // "bgAlpha": "70,80",
             "bgAngle": "180",

             "outCnvBaseFont": "Arial",
             "outCnvBaseFontSize": "11",
             "outCnvBaseFontColor": "#000000",

             "anchorRadius": "5",
              "anchorBorderThickness": "2",
              "anchorBorderColor": "#127fcb",
               "anchorSides": "3",
                "anchorBgColor": "#d3f7ff"
        },
        "categories": [{
          "category": [{
           "label": "Day Start"
          }]
        }],
        "dataset": [{
          "data": [{
            "value": "70"
          }]
        }]
      },
      "events": {
        "initialized": function(e) {
          function addLeadingZero(num) {
            return (num <= 9) ? ("0" + num) : num;
          }
              function updateData5() {
            // Get reference to the chart using its ID
          //  var chartRef3 = FusionCharts("stockRealTimeChart"),
              var chartRef5=e.sender,
              // We need to create a querystring format incremental update, containing
              // label in hh:mm:ss format
              // and a value (random).
              currDate = new Date(),
              label = addLeadingZero(currDate.getHours()) + ":" +
              addLeadingZero(currDate.getMinutes()) + ":" +
              addLeadingZero(currDate.getSeconds()),
              // Get random number between 35.25 & 35.75 - rounded to 2 decimal places
             //randomValue = Math.floor(Math.random() *
               // 50) / 100 + 35.25
                   database5=firebase.database();
                   firedata5=new Array();
                   //temp=new Array();
                   i=0;  
                      var leadsRef5 =database5.ref("UART/");
                      leadsRef5.limitToLast(1).on('value', function(snapshot) {
                      snapshot.forEach(function(childSnapshot) {
                      var childData5 = childSnapshot.val();
                      firedata5.push(childData5);
                      data000001=firedata5[firedata5.length- 1];
                      data000002=JSON.stringify(data000001);
                      data000003=JSON.parse(data000002);
                      console.log(data000003.temp);
                    /* for(i=0;i<firedata.length;i++){
                           console.log(firedata[i]); 
                           temp1=JSON.parse(firedata[i]);
                           console.log(temp1.temp)
                           strData = "&label=" + label +
                          "&value=" +(temp1.temp); 
                     }
                      });
               });
               strData5 = "&label=" + label +
                        "&value=" +data000003.temp; 
            console.log(strData5);
            chartRef5.feedData(strData5);
          }
          var myVar5 = setInterval(function() {
            updateData5();
          }, 5000);
        }
      }
    })
    .render();
}); */

